package com.cg.Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("uname").trim();
		String password = request.getParameter("pwd").trim();
		
		if (username.equals("admin") && password.equals("admin123")){
			
			HttpSession session =request.getSession();
			session.setAttribute("username",username);
			getServletContext().getRequestDispatcher("/InboxServlet").forward(request, response);
			
			
		}else {
			
			response.setContentType("text/html");
			PrintWriter pw = response.getWriter();
			
			pw.print("<html><body>"
					+"<h3>"
					+ "stupid fello enter correct username and password!<br/>"
					+ "<a href = 'index.html'>go to loginpage </a>"
					+"</h3>"
					+"</body></html>");
		}
	}

}
