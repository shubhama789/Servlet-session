package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/SuccessServlet")
public class SuccessServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(" in do get in success servlet");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in successpage");
		doGet(request, response);
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
			pw.print("<html><body>"
					+"<h3>"
					+"Welcome  !"
					+"<br/>"
					+"Today's Date : "+LocalDate.now()
					+"</h3>"
					+"</body></html>");

}
}
